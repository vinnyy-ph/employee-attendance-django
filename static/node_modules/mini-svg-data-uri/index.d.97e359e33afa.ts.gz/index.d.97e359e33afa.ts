declare function svgToTinyDataUri(svgString: string): string;

declare namespace svgToTinyDataUri {
  function toSrcset(svgString: string): string;
}

export = svgToTinyDataUri;