import svgToTinyDataUri from ".";

svgToTinyDataUri('xx');

svgToTinyDataUri.toSrcset('xxx');