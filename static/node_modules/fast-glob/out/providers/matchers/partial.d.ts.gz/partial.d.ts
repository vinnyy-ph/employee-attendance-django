import Matcher from './matcher';
export default class PartialMatcher extends Matcher {
    match(filepath: string): boolean;
}
